/**
 * QCM Classe – script Google Sheets
 * ------------------------------------------------------------
 * 1. Changez le mot de passe enseignant ci-dessous.
 * 2. Exécutez une fois la fonction « initialiser » (menu Exécuter).
 * 3. Déployez en « Application Web » (accès : Tout le monde).
 * Types de questions : une réponse, plusieurs réponses, réponse chiffrée, association.
 * Le guide d'installation détaille chaque étape.
 */

const MOT_DE_PASSE_ENSEIGNANT = "a-modifier";

const FEUILLE_QCM = "QCM";
const FEUILLE_RESULTATS = "Résultats";
const ENTETES_QCM = ["Identifiant", "Titre", "Mode", "Ouvert", "Mis à jour", "Contenu (ne pas modifier)"];
const ENTETES_RESULTATS = ["Date", "Identifiant QCM", "Titre", "Nom", "Prénom", "Classe", "Score", "Total",
  "Note /20", "Durée (min)", "Sorties de page", "Mode", "Réponses (ne pas modifier)"];

/* ---------- Points d'entrée ---------- */

function doGet(e) {
  const p = (e && e.parameter) || {};
  return repondre(() => {
    switch (p.action || "list") {
      case "ping": return { ok: true };
      case "list": return { ok: true, quizzes: lireQuiz().filter((q) => q.open).map(resume) };
      case "quiz": {
        const q = trouverQuiz(p.id);
        if (!q || !q.open) throw new Error("Ce QCM n'est pas disponible.");
        return { ok: true, quiz: versionEleve(q) };
      }
      default: throw new Error("Action inconnue.");
    }
  });
}

function doPost(e) {
  return repondre(() => {
    const b = JSON.parse((e && e.postData && e.postData.contents) || "{}");
    if (b.action === "submit") return soumettre(b);
    if (b.password !== MOT_DE_PASSE_ENSEIGNANT) throw new Error("Mot de passe enseignant incorrect.");
    switch (b.action) {
      case "login": return { ok: true };
      case "all": return { ok: true, quizzes: lireQuiz() };
      case "save": return { ok: true, quiz: enregistrerQuiz(b.quiz) };
      case "delete": supprimerQuiz(b.id); return { ok: true };
      case "results": return { ok: true, quiz: trouverQuiz(b.id), results: lireResultats(b.id) };
      default: throw new Error("Action inconnue.");
    }
  });
}

/* ---------- Élève ---------- */

function soumettre(b) {
  const q = trouverQuiz(b.quizId);
  if (!q || !q.open) throw new Error("Ce QCM est fermé : votre copie n'a pas pu être enregistrée.");
  const nom = texte(b.nom, 60), prenom = texte(b.prenom, 60), classe = texte(b.classe, 30);
  if (!nom || !prenom) throw new Error("Indiquez votre nom et votre prénom.");
  const reponses = b.answers || {};
  let score = 0, total = 0;
  const details = q.questions.map((qu) => {
    const choisi = reponses[qu.id];
    const part = noter(qu, choisi);
    const pts = Number(qu.points) || 1;
    total += pts;
    score += part * pts;
    return { id: qu.id, chosen: choisi === undefined ? null : choisi, part: part, ok: part === 1 };
  });
  score = Math.round(score * 100) / 100;
  const note = total ? Math.round((score / total) * 2000) / 100 : 0;
  const duree = Math.max(0, Math.round((Number(b.durationSec) || 0) / 6) / 10);
  const verrou = LockService.getScriptLock();
  verrou.waitLock(20000);
  try {
    feuille(FEUILLE_RESULTATS, ENTETES_RESULTATS).appendRow([new Date(), q.id, q.title, nom, prenom, classe,
      score, total, note, duree, Number(b.leaves) || 0, q.mode, JSON.stringify(reponses)]);
  } finally {
    verrou.releaseLock();
  }
  const res = { ok: true, saved: true };
  if (q.showScore !== false) Object.assign(res, { score: score, total: total, note: note });
  if (q.showCorrection) res.correction = { details: details, questions: q.questions };
  return res;
}

/* ---------- Stockage des QCM ---------- */

function lireQuiz() {
  const sh = feuille(FEUILLE_QCM, ENTETES_QCM);
  const n = sh.getLastRow() - 1;
  if (n < 1) return [];
  return sh.getRange(2, 1, n, 6).getValues()
    .filter((r) => r[0] && r[5])
    .map((r) => {
      const q = JSON.parse(r[5]);
      q.open = r[3] === true || r[3] === "OUI";
      return q;
    });
}

function trouverQuiz(id) {
  return lireQuiz().filter((q) => q.id === id)[0] || null;
}

function enregistrerQuiz(q) {
  if (!q || !q.id || !q.title) throw new Error("QCM incomplet : il faut au moins un titre.");
  if (!Array.isArray(q.questions) || !q.questions.length) throw new Error("Ajoutez au moins une question.");
  q.questions.forEach((qu, i) => {
    const n = "la question " + (i + 1);
    const t = typeDe(qu);
    if (!qu.text) throw new Error("La question " + (i + 1) + " n'a pas d'énoncé.");
    if (t === "single" || t === "multi") {
      if (!Array.isArray(qu.options) || qu.options.length < 2) throw new Error("Il faut au moins 2 réponses pour " + n + ".");
      if (t === "single" && !(qu.correct >= 0 && qu.correct < qu.options.length)) throw new Error("Indiquez la bonne réponse de " + n + ".");
      if (t === "multi" && !(Array.isArray(qu.corrects) && qu.corrects.length && qu.corrects.every((k) => k >= 0 && k < qu.options.length)))
        throw new Error("Cochez au moins une bonne réponse pour " + n + ".");
    } else if (t === "number") {
      if (qu.answer === "" || qu.answer === null || !isFinite(Number(qu.answer))) throw new Error("Indiquez la réponse chiffrée attendue pour " + n + ".");
    } else if (t === "match") {
      if (!Array.isArray(qu.choices) || qu.choices.length < 2) throw new Error("Il faut au moins 2 réponses proposées pour " + n + ".");
      if (!Array.isArray(qu.items) || !qu.items.length) throw new Error("Ajoutez au moins un élément à relier pour " + n + ".");
      if (!qu.items.every((it) => it.text && it.answer >= 0 && it.answer < qu.choices.length))
        throw new Error("Choisissez la bonne correspondance de chaque élément pour " + n + ".");
    } else {
      throw new Error("Type de question inconnu pour " + n + ".");
    }
  });
  q.updated = new Date().toISOString();
  const ligne = [q.id, q.title, q.mode === "evaluation" ? "Évaluation" : "Entraînement", q.open ? "OUI" : "NON",
    new Date(), JSON.stringify(q)];
  if (ligne[5].length > 49000) throw new Error("QCM trop long pour une cellule : scindez-le en deux.");
  const verrou = LockService.getScriptLock();
  verrou.waitLock(20000);
  try {
    const sh = feuille(FEUILLE_QCM, ENTETES_QCM);
    const ids = sh.getLastRow() > 1 ? sh.getRange(2, 1, sh.getLastRow() - 1, 1).getValues().map((r) => r[0]) : [];
    const i = ids.indexOf(q.id);
    if (i >= 0) sh.getRange(i + 2, 1, 1, 6).setValues([ligne]);
    else sh.appendRow(ligne);
  } finally {
    verrou.releaseLock();
  }
  return q;
}

function supprimerQuiz(id) {
  const sh = feuille(FEUILLE_QCM, ENTETES_QCM);
  if (sh.getLastRow() < 2) return;
  const ids = sh.getRange(2, 1, sh.getLastRow() - 1, 1).getValues().map((r) => r[0]);
  const i = ids.indexOf(id);
  if (i >= 0) sh.deleteRow(i + 2);
}

function lireResultats(id) {
  const q = trouverQuiz(id);
  const sh = feuille(FEUILLE_RESULTATS, ENTETES_RESULTATS);
  const n = sh.getLastRow() - 1;
  if (n < 1) return [];
  return sh.getRange(2, 1, n, 13).getValues()
    .filter((r) => r[1] === id)
    .map((r) => ({
      date: r[0] instanceof Date ? r[0].toISOString() : String(r[0]),
      nom: r[3], prenom: r[4], classe: r[5], score: r[6], total: r[7], note: r[8],
      duree: r[9], sorties: r[10], answers: lireJson(r[12]),
    }))
    .map((row) => {
      row.parts = {};
      if (q) q.questions.forEach((qu) => { row.parts[qu.id] = noter(qu, row.answers[qu.id]); });
      return row;
    });
}

/* ---------- Outils ---------- */

function resume(q) {
  return { id: q.id, title: q.title, mode: q.mode, duration: q.duration || 0, count: q.questions.length };
}

function versionEleve(q) {
  return {
    id: q.id, title: q.title, mode: q.mode, duration: q.duration || 0, shuffle: !!q.shuffle,
    context: q.context || "",
    questions: q.questions.map((qu) => {
      const t = typeDe(qu);
      const out = { id: qu.id, type: t, text: qu.text, points: qu.points || 1 };
      if (t === "single" || t === "multi") out.options = qu.options.map((o) => ({ text: o.text }));
      if (t === "number") out.unit = qu.unit || "";
      if (t === "match") { out.choices = qu.choices.slice(); out.items = qu.items.map((it) => ({ text: it.text })); }
      return out;
    }),
  };
}

function typeDe(qu) {
  return qu.type || "single";
}

/** Part des points obtenue (de 0 à 1) pour une réponse. */
function noter(qu, a) {
  if (a === undefined || a === null) return 0;
  const t = typeDe(qu);
  if (t === "single") return a === qu.correct ? 1 : 0;
  if (t === "multi") {
    if (!Array.isArray(a)) return 0;
    const bonnes = qu.corrects || [];
    const choix = a.filter((x, i) => a.indexOf(x) === i);
    const justes = choix.filter((x) => bonnes.indexOf(x) >= 0).length;
    const fausses = choix.length - justes;
    return bonnes.length ? Math.max(0, (justes - fausses) / bonnes.length) : 0;
  }
  if (t === "number") {
    const x = Number(a);
    if (a === "" || !isFinite(x)) return 0;
    return Math.abs(x - Number(qu.answer)) <= (Number(qu.tolerance) || 0) + 1e-9 ? 1 : 0;
  }
  if (t === "match") {
    if (!Array.isArray(a) || !qu.items.length) return 0;
    return qu.items.filter((it, i) => a[i] === it.answer).length / qu.items.length;
  }
  return 0;
}

function feuille(nom, entetes) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(nom);
  if (!sh) {
    sh = ss.insertSheet(nom);
    sh.appendRow(entetes);
    sh.setFrozenRows(1);
    sh.getRange(1, 1, 1, entetes.length).setFontWeight("bold");
  }
  return sh;
}

function texte(v, max) {
  return String(v || "").replace(/[\u0000-\u001f]/g, " ").trim().slice(0, max);
}

function lireJson(s) {
  try { return JSON.parse(s); } catch (e) { return {}; }
}

function repondre(fn) {
  let out;
  try { out = fn(); } catch (err) { out = { ok: false, error: String((err && err.message) || err) }; }
  return ContentService.createTextOutput(JSON.stringify(out)).setMimeType(ContentService.MimeType.JSON);
}

/* ---------- Installation ---------- */

/** À exécuter une seule fois : crée les onglets et ajoute le QCM d'exemple LAVANDINE (fermé). */
function initialiser() {
  feuille(FEUILLE_QCM, ENTETES_QCM);
  feuille(FEUILLE_RESULTATS, ENTETES_RESULTATS);
  if (!trouverQuiz(EXEMPLE_LAVANDINE.id)) enregistrerQuiz(JSON.parse(JSON.stringify(EXEMPLE_LAVANDINE)));
}

const EXEMPLE_LAVANDINE = {
 "id": "lavandine-budgets",
 "title": "LAVANDINE – Budgets et trésorerie",
 "mode": "evaluation",
 "open": false,
 "duration": 45,
 "shuffle": false,
 "showScore": true,
 "showCorrection": false,
 "context": "## Présentation\nLa société LAVANDINE fabrique des savons artisanaux qu'elle vend à des boutiques et à des parfumeries. Pour accompagner sa croissance, elle prévoit d'acheter en février une machine de découpe.\n\n## Document 1 – Ventes du 1er trimestre N+1\n| | Janvier | Février | Mars |\n|---|---|---|---|\n| Ventes de savons (HT) | 40 000 | 50 000 | 60 000 |\n- 60 % des ventes sont encaissées au comptant, 40 % à 30 jours fin de mois.\n- Taux de TVA : 20 %. La TVA due au titre d'un mois est payée le 15 du mois suivant.\n- Un crédit de TVA est imputé sur la TVA due du mois suivant.\n\n## Document 2 – Dépenses du 1er trimestre N+1\n| | Janvier | Février | Mars |\n|---|---|---|---|\n| Achats de matières premières (HT) | 12 000 | 15 000 | 18 000 |\n| Charges externes (HT) | 2 000 | 2 000 | 2 000 |\n| Salaires nets | 12 000 | 12 000 | 12 000 |\n- Matières premières réglées pour 50 % à 30 jours fin de mois et 50 % à 60 jours fin de mois.\n- Charges externes (TVA à 20 %) payées le mois même.\n- Assurance annuelle de 1 200 €, exonérée de TVA, payée en janvier.\n- Charges sociales : 45 % des salaires nets. Salaires et charges sociales payés le mois suivant.\n\n## Document 3 – Investissement\n- Machine de découpe : 60 000 € HT (TVA à 20 %), livrée et payée comptant en février N+1.\n- Amortissement linéaire sur 5 ans.\n\n## Document 4 – Dettes et créances au 31 décembre N\n| Règlements en : | Janvier | Février |\n|---|---|---|\n| Clients | 30 000 | |\n| Fournisseurs | 20 000 | 9 000 |\n| Salaires de décembre | 12 000 | |\n| Charges sociales de décembre | 5 400 | |\n| TVA de décembre | 4 200 | |\n\n## Document 5 – Informations complémentaires\n| | Au 31/12/N | Au 31/03/N+1 |\n|---|---|---|\n| Solde banque | 2 000 | à déterminer |\n| Stock de matières premières | 8 000 | 9 500 |\n| Stock de produits finis | 12 000 | 10 000 |",
 "questions": [
  {
   "id": "q01",
   "text": "Quel est le montant des encaissements clients de janvier ?",
   "points": 1,
   "explanation": "30 000 (créances du 31/12) + 60 % × 48 000 TTC = 58 800.",
   "correct": 1,
   "options": [
    {
     "text": "54 000 €",
     "why": "Calcul sur les ventes HT (30 000 + 60 % × 40 000)."
    },
    {
     "text": "58 800 €",
     "why": ""
    },
    {
     "text": "28 800 €",
     "why": "Oubli des créances du 31/12 encaissées en janvier."
    },
    {
     "text": "78 000 €",
     "why": "Toutes les ventes de janvier encaissées au comptant."
    }
   ]
  },
  {
   "id": "q02",
   "text": "Quel est le montant des encaissements clients de mars ?",
   "points": 1,
   "explanation": "40 % × 60 000 (février) + 60 % × 72 000 (mars) = 24 000 + 43 200 = 67 200.",
   "correct": 2,
   "options": [
    {
     "text": "56 000 €",
     "why": "Calcul sur les ventes HT."
    },
    {
     "text": "43 200 €",
     "why": "Oubli des 40 % de février encaissés en mars."
    },
    {
     "text": "67 200 €",
     "why": ""
    },
    {
     "text": "72 000 €",
     "why": "Ventes TTC de mars, sans décalage."
    }
   ]
  },
  {
   "id": "q03",
   "text": "Quel est le montant des créances clients au 31 mars N+1 ?",
   "points": 1,
   "explanation": "Seuls les 40 % des ventes de mars restent à encaisser : 40 % × 72 000 = 28 800.",
   "correct": 0,
   "options": [
    {
     "text": "28 800 €",
     "why": ""
    },
    {
     "text": "24 000 €",
     "why": "40 % des ventes de mars HT."
    },
    {
     "text": "43 200 €",
     "why": "Part encaissée au comptant, et non la part à crédit."
    },
    {
     "text": "19 200 €",
     "why": "40 % des ventes de janvier, déjà encaissées en février."
    }
   ]
  },
  {
   "id": "q04",
   "text": "Quel est le montant payé aux fournisseurs de matières premières en février ?",
   "points": 1,
   "explanation": "9 000 (dette du 31/12) + 50 % × 14 400 (achats TTC de janvier) = 16 200.",
   "correct": 2,
   "options": [
    {
     "text": "9 000 €",
     "why": "Oubli de la moitié des achats de janvier."
    },
    {
     "text": "15 000 €",
     "why": "Achats de janvier pris HT (9 000 + 50 % × 12 000)."
    },
    {
     "text": "16 200 €",
     "why": ""
    },
    {
     "text": "23 400 €",
     "why": "Achats de janvier payés en totalité en février."
    }
   ]
  },
  {
   "id": "q05",
   "text": "Quel est le montant des dettes fournisseurs au 31 mars N+1 ?",
   "points": 1,
   "explanation": "50 % × 18 000 (février) + 21 600 (mars) = 30 600.",
   "correct": 3,
   "options": [
    {
     "text": "21 600 €",
     "why": "Oubli de la moitié des achats de février, payable fin avril."
    },
    {
     "text": "25 500 €",
     "why": "Calcul sur les achats HT."
    },
    {
     "text": "39 600 €",
     "why": "Achats de février comptés en totalité."
    },
    {
     "text": "30 600 €",
     "why": ""
    }
   ]
  },
  {
   "id": "q06",
   "text": "Quel montant de salaires et charges sociales est décaissé en janvier ?",
   "points": 1,
   "explanation": "Salaires et charges de décembre payés en janvier : 12 000 + 5 400 = 17 400.",
   "correct": 3,
   "options": [
    {
     "text": "12 000 €",
     "why": "Oubli des charges sociales."
    },
    {
     "text": "0 €",
     "why": "Oubli des salaires de décembre payés en janvier."
    },
    {
     "text": "34 800 €",
     "why": "Salaires de décembre et de janvier payés en janvier."
    },
    {
     "text": "17 400 €",
     "why": ""
    }
   ]
  },
  {
   "id": "q07",
   "text": "Quel est le montant de la TVA déductible sur biens et services en janvier ?",
   "points": 1,
   "explanation": "20 % × (12 000 + 2 000) = 2 800. L'assurance n'est pas soumise à la TVA.",
   "correct": 1,
   "options": [
    {
     "text": "2 400 €",
     "why": "Oubli de la TVA sur les charges externes."
    },
    {
     "text": "2 800 €",
     "why": ""
    },
    {
     "text": "3 040 €",
     "why": "TVA appliquée à tort sur l'assurance, exonérée."
    },
    {
     "text": "14 000 €",
     "why": "Montant HT des achats et charges, pas la TVA."
    }
   ]
  },
  {
   "id": "q08",
   "text": "Quel montant de TVA est payé en janvier ?",
   "points": 1,
   "explanation": "On paie en janvier la TVA due au titre de décembre : 4 200.",
   "correct": 2,
   "options": [
    {
     "text": "5 200 €",
     "why": "TVA due de janvier, payée seulement le 15 février."
    },
    {
     "text": "8 000 €",
     "why": "TVA collectée de janvier."
    },
    {
     "text": "4 200 €",
     "why": ""
    },
    {
     "text": "0 €",
     "why": "Oubli de la TVA de décembre."
    }
   ]
  },
  {
   "id": "q09",
   "text": "Quelle est la situation de TVA au titre du mois de février ?",
   "points": 1,
   "explanation": "10 000 – (3 000 + 400 + 12 000) = – 5 400 : crédit de TVA reporté sur mars.",
   "correct": 1,
   "options": [
    {
     "text": "TVA à décaisser de 6 600 €",
     "why": "Oubli de la TVA déductible sur la machine."
    },
    {
     "text": "Crédit de TVA de 5 400 €",
     "why": ""
    },
    {
     "text": "TVA à décaisser de 10 000 €",
     "why": "TVA collectée, sans déduction."
    },
    {
     "text": "Crédit de TVA de 12 000 €",
     "why": "Seule la TVA sur la machine est prise en compte."
    }
   ]
  },
  {
   "id": "q10",
   "text": "Quel montant de TVA est payé en mars ?",
   "points": 1,
   "explanation": "Février se solde par un crédit : rien à payer en mars. La TVA de mars (12 000 – 4 000 – 5 400 = 2 600) sera payée en avril.",
   "correct": 0,
   "options": [
    {
     "text": "0 €",
     "why": ""
    },
    {
     "text": "6 600 €",
     "why": "Crédit de février ignoré."
    },
    {
     "text": "2 600 €",
     "why": "TVA due de mars, payée seulement le 15 avril."
    },
    {
     "text": "– 5 400 € (remboursement)",
     "why": "Le crédit est imputé sur le mois suivant, pas remboursé."
    }
   ]
  },
  {
   "id": "q11",
   "text": "Quel décaissement la machine de découpe entraîne-t-elle en février ?",
   "points": 1,
   "explanation": "La machine est payée comptant TTC : 60 000 × 1,2 = 72 000.",
   "correct": 0,
   "options": [
    {
     "text": "72 000 €",
     "why": ""
    },
    {
     "text": "60 000 €",
     "why": "Montant HT : on décaisse le TTC."
    },
    {
     "text": "12 000 €",
     "why": "Dotation annuelle aux amortissements."
    },
    {
     "text": "1 000 €",
     "why": "Dotation mensuelle aux amortissements."
    }
   ]
  },
  {
   "id": "q12",
   "text": "Quel est le total des décaissements de février ?",
   "points": 1,
   "explanation": "16 200 + 2 400 + 17 400 + 72 000 + 5 200 = 113 200.",
   "correct": 3,
   "options": [
    {
     "text": "101 200 €",
     "why": "Machine comptée HT."
    },
    {
     "text": "95 800 €",
     "why": "Oubli des salaires et charges de janvier."
    },
    {
     "text": "108 000 €",
     "why": "Oubli de la TVA de janvier payée en février."
    },
    {
     "text": "113 200 €",
     "why": ""
    }
   ]
  },
  {
   "id": "q13",
   "text": "Quelle est la trésorerie à la fin du mois de février ?",
   "points": 1,
   "explanation": "15 600 (fin janvier) + 55 200 – 113 200 = – 42 400.",
   "correct": 1,
   "options": [
    {
     "text": "– 58 000 €",
     "why": "Solde du mois, sans la trésorerie de début de mois."
    },
    {
     "text": "– 42 400 €",
     "why": ""
    },
    {
     "text": "15 600 €",
     "why": "Trésorerie de fin janvier."
    },
    {
     "text": "– 30 400 €",
     "why": "Machine comptée HT."
    }
   ]
  },
  {
   "id": "q14",
   "text": "Quelle est la trésorerie à la fin du mois de mars ?",
   "points": 1,
   "explanation": "– 42 400 + 67 200 – 36 000 = – 11 200.",
   "correct": 0,
   "options": [
    {
     "text": "– 11 200 €",
     "why": ""
    },
    {
     "text": "31 200 €",
     "why": "Solde du mois de mars seul."
    },
    {
     "text": "– 13 800 €",
     "why": "TVA de mars payée en mars."
    },
    {
     "text": "– 17 800 €",
     "why": "Crédit de TVA ignoré (6 600 payés en mars)."
    }
   ]
  },
  {
   "id": "q15",
   "text": "Quel est le BFR d'exploitation au 31 mars N+1 ?",
   "points": 1,
   "explanation": "19 500 + 28 800 – 30 600 – 17 400 – 2 600 = – 2 300.",
   "correct": 2,
   "options": [
    {
     "text": "– 21 800 €",
     "why": "Oubli des stocks."
    },
    {
     "text": "2 300 €",
     "why": "Erreur de signe."
    },
    {
     "text": "– 2 300 €",
     "why": ""
    },
    {
     "text": "15 100 €",
     "why": "Oubli des dettes de salaires et charges sociales."
    }
   ]
  },
  {
   "id": "q16",
   "text": "Pourquoi la dotation aux amortissements de la machine n'apparaît-elle pas dans le budget de trésorerie ?",
   "points": 1,
   "explanation": "Le seul décaissement est le paiement de la machine. La dotation réduit le résultat, pas la trésorerie.",
   "correct": 2,
   "options": [
    {
     "text": "Elle est réglée en fin d'exercice, hors du trimestre étudié.",
     "why": "Une dotation n'est jamais réglée."
    },
    {
     "text": "Elle est exonérée de TVA.",
     "why": "Sans rapport avec la trésorerie."
    },
    {
     "text": "C'est une charge calculée qui ne donne lieu à aucun paiement.",
     "why": ""
    },
    {
     "text": "Elle ne concerne que les entreprises soumises à l'impôt sur les sociétés.",
     "why": "Faux : toute entreprise amortit ses immobilisations."
    }
   ]
  },
  {
   "id": "q17",
   "text": "Que signifie un BFR d'exploitation négatif ?",
   "points": 1,
   "explanation": "Chez LAVANDINE, il s'explique par les 60 % de ventes encaissées comptant et les délais fournisseurs.",
   "correct": 1,
   "options": [
    {
     "text": "L'entreprise est en difficulté de trésorerie.",
     "why": "Confusion entre BFR et trésorerie."
    },
    {
     "text": "Le cycle d'exploitation dégage une ressource : les dettes d'exploitation financent plus que les stocks et les créances.",
     "why": ""
    },
    {
     "text": "L'entreprise réalise une perte.",
     "why": "Confusion entre BFR et résultat."
    },
    {
     "text": "Les stocks sont trop élevés.",
     "why": "Des stocks élevés augmentent le BFR."
    }
   ]
  },
  {
   "id": "q18",
   "text": "Quelle est la cause principale de la trésorerie négative de LAVANDINE ?",
   "points": 1,
   "explanation": "Sans la machine (72 000 TTC), les soldes mensuels seraient positifs.",
   "correct": 3,
   "options": [
    {
     "text": "Un BFR trop élevé.",
     "why": "Le BFR est négatif : c'est une ressource."
    },
    {
     "text": "Des ventes insuffisantes.",
     "why": "L'exploitation dégage des soldes positifs."
    },
    {
     "text": "Le crédit de TVA de février.",
     "why": "Il allège au contraire les décaissements de mars."
    },
    {
     "text": "Le paiement comptant de la machine sans financement adapté.",
     "why": ""
    }
   ]
  },
  {
   "id": "q19",
   "text": "Selon la règle de l'équilibre financier, quelle solution est la plus adaptée ?",
   "points": 1,
   "explanation": "Un emploi durable (immobilisation) doit être financé par une ressource durable.",
   "correct": 0,
   "options": [
    {
     "text": "Un emprunt à moyen terme pour financer la machine.",
     "why": ""
    },
    {
     "text": "Un découvert bancaire maintenu pendant 5 ans.",
     "why": "Ressource de court terme et coûteuse pour un besoin durable."
    },
    {
     "text": "Une baisse des salaires.",
     "why": "Ne répond pas au besoin de financement de l'investissement."
    },
    {
     "text": "L'allongement des délais de paiement accordés aux clients.",
     "why": "Aggrave la trésorerie."
    }
   ]
  },
  {
   "id": "q20",
   "text": "Si LAVANDINE encaissait toutes ses ventes à 30 jours fin de mois (au lieu de 60 % au comptant), son BFR :",
   "points": 1,
   "explanation": "Les créances clients au 31/03 passeraient de 28 800 à 72 000 : le BFR augmenterait de 43 200.",
   "correct": 2,
   "options": [
    {
     "text": "diminuerait.",
     "why": "Plus de créances = plus de besoin."
    },
    {
     "text": "ne changerait pas.",
     "why": "Les créances clients font partie du BFR."
    },
    {
     "text": "augmenterait.",
     "why": ""
    },
    {
     "text": "deviendrait nul.",
     "why": "Aucune raison."
    }
   ]
  }
 ]
};
