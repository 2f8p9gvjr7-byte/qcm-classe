/*
 * Collez ici l'adresse de votre application Web Google Apps Script
 * (elle se termine par /exec). Voir le guide d'installation, étape 3.
 */
window.QCM_CONFIG = {
  API_URL: "COLLEZ_ICI_L_ADRESSE_DE_VOTRE_SCRIPT",
};
